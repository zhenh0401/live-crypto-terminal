from flask import Flask, jsonify, render_template_string, request, send_file
import sqlite3
import os

app = Flask(__name__)

def get_db_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'crypto_data.db')

def init_db():
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS wallet (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            usd_balance REAL,
            btc_balance REAL,
            eth_balance REAL
        )
    ''')
    cursor.execute('SELECT * FROM wallet')
    if not cursor.fetchone():
        cursor.execute('INSERT INTO wallet (id, usd_balance, btc_balance, eth_balance) VALUES (1, 10000.0, 0.0, 0.0)')
        
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS price_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            symbol TEXT,
            price_usd REAL,
            price_ron REAL,
            hype_score INTEGER DEFAULT 0
        )
    ''')
    
    try:
        cursor.execute('ALTER TABLE price_history ADD COLUMN hype_score INTEGER DEFAULT 0')
    except:
        pass 
        
    conn.commit()
    conn.close()

init_db()

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Crypto Tracker</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background-color: #0f0f17; color: #ffffff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; text-align: center; padding: 20px; }
        .dashboard { display: flex; justify-content: center; gap: 40px; margin-bottom: 40px; flex-wrap: wrap; }
        .coin-box { background-color: #1c1c2e; padding: 30px; border-radius: 15px; min-width: 250px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        .symbol { font-size: 24px; color: #8888aa; font-weight: bold; }
        .price { font-size: 32px; font-weight: bold; color: #00ffaa; margin-top: 10px; }
        .ron-price { font-size: 14px; color: #aaaacc; margin-top: 5px; }
        .hype-badge { display: inline-block; background-color: #ff4d4d; color: white; padding: 5px 10px; border-radius: 10px; font-size: 12px; font-weight: bold; margin-top: 10px; }
        .chart-container { background-color: #1c1c2e; padding: 30px; border-radius: 15px; max-width: 800px; margin: 0 auto 40px auto; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        .wallet-box { background-color: #1c1c2e; padding: 20px; border-radius: 15px; max-width: 800px; margin: 0 auto 40px auto; box-shadow: 0 4px 15px rgba(0,0,0,0.5); display: flex; justify-content: space-around; align-items: center; flex-wrap: wrap; }
        .wallet-item { margin: 10px; }
        .wallet-label { color: #8888aa; font-size: 14px; }
        .wallet-value { font-size: 24px; font-weight: bold; color: #ffffff; }
        .btn-group { margin-top: 15px; display: flex; gap: 10px; justify-content: center; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 14px; transition: 0.2s; }
        .btn-buy { background-color: #00ffaa; color: #000000; }
        .btn-sell { background-color: #ff4d4d; color: #ffffff; }
        .btn:hover { transform: scale(1.05); }
        .error-msg { color: #ff4d4d; margin-top: 10px; font-weight: bold; min-height: 20px; }
        
        #start-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background-color: #0f0f17; display: flex; justify-content: center; align-items: center;
            z-index: 9999; cursor: pointer; flex-direction: column;
        }
        #start-overlay h1 { font-size: 60px; color: #00ffaa; margin-bottom: 20px; text-shadow: 0 0 20px #00ffaa; }
        #start-overlay p { font-size: 24px; color: #8888aa; animation: pulse 2s infinite; }
        @keyframes pulse { 0% {opacity: 0.5;} 50% {opacity: 1;} 100% {opacity: 0.5;} }
    </style>
</head>
<body>

    <div id="start-overlay" onclick="startApp()">
        <h1>LIVE CRYPTO TERMINAL</h1>
        <p>[ CLICK TO INITIALIZE ]</p>
    </div>
    
    <audio id="bg-music" loop>
        <source src="/api/music" type="audio/mpeg">
    </audio>

    <h1>LIVE CRYPTO TERMINAL</h1>
    
    <div class="wallet-box">
        <div class="wallet-item">
            <div class="wallet-label">USD BALANCE</div>
            <div id="usd-bal" class="wallet-value">$10,000.00</div>
        </div>
        <div class="wallet-item">
            <div class="wallet-label">BTC HELD</div>
            <div id="btc-bal" class="wallet-value">0.00000</div>
        </div>
        <div class="wallet-item">
            <div class="wallet-label">ETH HELD</div>
            <div id="eth-bal" class="wallet-value">0.00000</div>
        </div>
    </div>

    <div class="dashboard">
        <div class="coin-box">
            <div class="symbol">BITCOIN (BTC)</div>
            <div id="btc-usd" class="price">Loading...</div>
            <div id="btc-ron" class="ron-price">Loading RON...</div>
            <div id="btc-hype" class="hype-badge">HYPE: 0</div>
            <div id="btc-error" class="error-msg"></div>
            <div class="btn-group">
                <button class="btn btn-buy" onclick="trade('buy', 'BTC')">Buy $100</button>
                <button class="btn btn-sell" onclick="trade('sell', 'BTC')">Sell $100</button>
            </div>
        </div>
        <div class="coin-box">
            <div class="symbol">ETHEREUM (ETH)</div>
            <div id="eth-usd" class="price">Loading...</div>
            <div id="eth-ron" class="ron-price">Loading RON...</div>
            <div id="eth-hype" class="hype-badge">HYPE: 0</div>
            <div id="eth-error" class="error-msg"></div>
            <div class="btn-group">
                <button class="btn btn-buy" onclick="trade('buy', 'ETH')">Buy $100</button>
                <button class="btn btn-sell" onclick="trade('sell', 'ETH')">Sell $100</button>
            </div>
        </div>
    </div>

    <div class="chart-container">
        <canvas id="priceChart"></canvas>
    </div>

    <script>
        let currentPrices = { BTC: 80000, ETH: 3000 };
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

        function startApp() {
            document.getElementById('start-overlay').style.display = 'none';
            const bgMusic = document.getElementById('bg-music');
            bgMusic.volume = 0.15; 
            bgMusic.play();
            fetchPrices();
            fetchWallet();
            setInterval(fetchPrices, 3000);
            setInterval(fetchWallet, 3000);
        }

        function playRichSound() {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(1200, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(1800, audioCtx.currentTime + 0.1);
            gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
            osc.start(audioCtx.currentTime);
            osc.stop(audioCtx.currentTime + 0.3);
        }

        function playFaintingSound() {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(400, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(100, audioCtx.currentTime + 0.6);
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.6);
            osc.start(audioCtx.currentTime);
            osc.stop(audioCtx.currentTime + 0.6);
        }

        const ctx = document.getElementById('priceChart').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'line',
            data: { labels: [], datasets: [
                { label: 'BTC Price (USD)', data: [], borderColor: '#f7931a', backgroundColor: 'rgba(247, 147, 26, 0.1)', borderWidth: 2, fill: true, tension: 0.4, yAxisID: 'y' },
                { label: 'ETH Price (USD)', data: [], borderColor: '#627eea', backgroundColor: 'rgba(98, 126, 234, 0.1)', borderWidth: 2, fill: true, tension: 0.4, yAxisID: 'y1' },
                { label: 'BTC Hype Score', data: [], borderColor: '#ff4d4d', borderWidth: 2, borderDash: [5, 5], fill: false, tension: 0.4, yAxisID: 'y2' }
            ]},
            options: {
                responsive: true,
                interaction: { mode: 'index', intersect: false },
                scales: {
                    y: { type: 'linear', display: true, position: 'left', beginAtZero: false, grid: { color: '#2a2a4a' }, ticks: { color: '#f7931a' } },
                    y1: { type: 'linear', display: true, position: 'right', beginAtZero: false, grid: { drawOnChartArea: false }, ticks: { color: '#627eea' } },
                    y2: { type: 'linear', display: false, beginAtZero: true },
                    x: { grid: { color: '#2a2a4a' }, ticks: { color: '#8888aa' } }
                }
            }
        });

        async function fetchPrices() {
            const response = await fetch('/api/prices');
            const data = await response.json();
            if(data.btc){
                document.getElementById('btc-usd').innerText = '$' + data.btc.usd.toLocaleString();
                document.getElementById('btc-ron').innerText = data.btc.ron.toLocaleString() + ' RON';
                document.getElementById('btc-hype').innerText = 'HYPE: ' + data.btc.hype;
                currentPrices.BTC = data.btc.usd;
            }
            if(data.eth){
                document.getElementById('eth-usd').innerText = '$' + data.eth.usd.toLocaleString();
                document.getElementById('eth-ron').innerText = data.eth.ron.toLocaleString() + ' RON';
                document.getElementById('eth-hype').innerText = 'HYPE: ' + data.eth.hype;
                currentPrices.ETH = data.eth.usd;
            }
            chart.data.labels = data.timestamps;
            chart.data.datasets[0].data = data.btc_history;
            chart.data.datasets[1].data = data.eth_history;
            chart.data.datasets[2].data = data.btc_hype_history;
            chart.update();
        }

        async function fetchWallet() {
            const response = await fetch('/api/wallet');
            const data = await response.json();
            document.getElementById('usd-bal').innerText = '$' + parseFloat(data.usd).toFixed(2);
            document.getElementById('btc-bal').innerText = parseFloat(data.btc).toFixed(5);
            document.getElementById('eth-bal').innerText = parseFloat(data.eth).toFixed(5);
        }

        async function trade(action, coin) {
            const errorId = coin.toLowerCase() + '-error';
            document.getElementById(errorId).innerText = ""; 
            try {
                const response = await fetch('/api/trade', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: action, coin: coin })
                });
                if (!response.ok) {
                    const errData = await response.json();
                    document.getElementById(errorId).innerText = errData.error;
                    playFaintingSound();
                } else {
                    const isHigh = (coin === 'BTC' && currentPrices.BTC > 79000) || (coin === 'ETH' && currentPrices.ETH > 2200);
                    if(isHigh) { playRichSound(); } else { playFaintingSound(); }
                    fetchWallet();
                }
            } catch (e) {
                document.getElementById(errorId).innerText = "Trade failed!";
                playFaintingSound();
            }
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML)

@app.route('/api/music')
def get_music():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    song_name = r"bg_music=apikey019376218.project.bsb.showcase-crypto%20tracker%20.mp3"
    song_path = os.path.join(base_dir, song_name)
    
    if os.path.exists(song_path):
        return send_file(song_path, mimetype='audio/mpeg')
    return "Song not found", 404

@app.route('/api/prices')
def get_prices():
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    
    cursor.execute('SELECT timestamp, symbol, price_usd, price_ron, hype_score FROM price_history ORDER BY id DESC LIMIT 40')
    rows = cursor.fetchall()
    
    cursor.execute('SELECT MAX(hype_score) FROM price_history WHERE symbol="BTC" AND id > (SELECT MAX(id) FROM price_history) - 20')
    max_btc_hype = cursor.fetchone()[0] or 0
    
    cursor.execute('SELECT MAX(hype_score) FROM price_history WHERE symbol="ETH" AND id > (SELECT MAX(id) FROM price_history) - 20')
    max_eth_hype = cursor.fetchone()[0] or 0
    
    conn.close()

    btc_history = []
    eth_history = []
    btc_hype_history = []
    timestamps = []
    
    latest_btc = None
    latest_eth = None

    for row in reversed(rows):
        time_str = row[0].split(' ')[1][:5] 
        symbol = row[1]
        usd = row[2]
        ron = row[3]
        hype = row[4]

        if symbol == 'BTC':
            if not latest_btc: latest_btc = {"usd": usd, "ron": ron, "hype": max_btc_hype}
            btc_history.append(usd)
            btc_hype_history.append(hype)
            timestamps.append(time_str)
        elif symbol == 'ETH':
            if not latest_eth: latest_eth = {"usd": usd, "ron": ron, "hype": max_eth_hype}
            eth_history.append(usd)

    return jsonify({
        "btc": latest_btc,
        "eth": latest_eth,
        "timestamps": timestamps,
        "btc_history": btc_history,
        "eth_history": eth_history,
        "btc_hype_history": btc_hype_history
    })

@app.route('/api/trade', methods=['POST'])
def trade():
    data = request.json
    action = data.get('action')
    coin = data.get('coin')
    
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    
    cursor.execute('SELECT price_usd FROM price_history WHERE symbol=? ORDER BY id DESC LIMIT 1', (coin,))
    price_row = cursor.fetchone()
    if not price_row: return jsonify({"error": "No price data"}), 400
    current_price = price_row[0]

    cursor.execute('SELECT usd_balance, btc_balance, eth_balance FROM wallet WHERE id=1')
    usd, btc, eth = cursor.fetchone()

    amount_usd = 100.0 

    if action == 'buy':
        if usd < amount_usd: return jsonify({"error": "Not enough USD!"}), 400
        usd -= amount_usd
        coin_amount = amount_usd / current_price
        if coin == 'BTC': btc += coin_amount
        elif coin == 'ETH': eth += coin_amount
    elif action == 'sell':
        coin_amount = amount_usd / current_price
        if coin == 'BTC' and btc >= coin_amount: 
            btc -= coin_amount
            usd += amount_usd
        elif coin == 'ETH' and eth >= coin_amount: 
            eth -= coin_amount
            usd += amount_usd
        else: 
            return jsonify({"error": f"Not enough {coin}!"}), 400

    cursor.execute('UPDATE wallet SET usd_balance=?, btc_balance=?, eth_balance=? WHERE id=1', (usd, btc, eth))
    conn.commit()
    conn.close()
    
    return jsonify({"usd": usd, "btc": btc, "eth": eth})

@app.route('/api/wallet')
def wallet():
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    cursor.execute('SELECT usd_balance, btc_balance, eth_balance FROM wallet WHERE id=1')
    row = cursor.fetchone()
    conn.close()
    return jsonify({"usd": row[0], "btc": row[1], "eth": row[2]})

if __name__ == '__main__':
    app.run(debug=True)