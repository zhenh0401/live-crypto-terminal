import requests
import sqlite3
import time
import random
import feedparser
import os
from datetime import datetime

db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'crypto_data.db')
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS price_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        symbol TEXT,
        price_usd REAL,
        price_ron REAL,
        hype_score INTEGER DEFAULT 0
    )
''')
conn.commit()

print("Fetching initial real prices...")
try:
    url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd,ron"
    response = requests.get(url)
    data = response.json()
    
    btc_usd = data['bitcoin']['usd']
    eth_usd = data['ethereum']['usd']
    ron_rate = data['bitcoin']['ron'] / data['bitcoin']['usd']
    
    print("Success! Starting simulation.")
except Exception:
    print("API is still blocked. Using default starting prices.")
    btc_usd = 80000.0
    eth_usd = 3000.0
    ron_rate = 4.42

btc_base_hype = 100
eth_base_hype = 102
scan_counter = 0

def get_hype_score(coin_name):
    try:
        feed_url = f"https://news.google.com/rss/search?q={coin_name}+crypto&hl=en-US&gl=US&ceid=US:en"
        feed = feedparser.parse(feed_url)
        if feed.entries and len(feed.entries) > 20:
            return len(feed.entries)
    except:
        pass
    return 0

while True:
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    btc_usd += random.uniform(-50, 50)
    eth_usd += random.uniform(-3, 3)

    btc_ron = round(btc_usd * ron_rate, 2)
    eth_ron = round(eth_usd * ron_rate, 2)

    scan_counter += 1
    if scan_counter >= 12:
        print("Scanning Google News for real baseline Hype...")
        new_btc = get_hype_score("Bitcoin")
        new_eth = get_hype_score("Ethereum")
        if new_btc > 0: btc_base_hype = new_btc
        if new_eth > 0: eth_base_hype = new_eth
        scan_counter = 0

    btc_display_hype = max(50, btc_base_hype + random.randint(-25, 25))
    eth_display_hype = max(50, eth_base_hype + random.randint(-25, 25))

    cursor.execute('INSERT INTO price_history (timestamp, symbol, price_usd, price_ron, hype_score) VALUES (?, ?, ?, ?, ?)', 
                   (current_time, 'BTC', btc_usd, btc_ron, btc_display_hype))
    cursor.execute('INSERT INTO price_history (timestamp, symbol, price_usd, price_ron, hype_score) VALUES (?, ?, ?, ?, ?)', 
                   (current_time, 'ETH', eth_usd, eth_ron, eth_display_hype))
    conn.commit()

    print(f"Saved: {current_time} | BTC: ${btc_usd:.2f} (Hype: {btc_display_hype}) | ETH: ${eth_usd:.2f} (Hype: {eth_display_hype})")
    time.sleep(5)